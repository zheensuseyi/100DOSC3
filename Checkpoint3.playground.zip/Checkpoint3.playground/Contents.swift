// Zheen H. Suseyi
// 09/21/2024


/*
 Your goal is to loop from 1 through 100, and for each number:

If it’s a multiple of 3, print “Fizz”
If it’s a multiple of 5, print “Buzz”
If it’s a multiple of 3 and 5, print “FizzBuzz”
Otherwise, just print the number.
 
*/
import UIKit

// defining our variable we are gonna loop with
var i = 1
// looping thru numbers 1-100
while i < 101 {
    // if the number is a multiple of 3 and 5, print fizzbuzz
    if i % 3 == 0 && i % 5 == 0 {
        print("\(i) Fizzbuzz")
    }
    // if the number is a multiple of 5, print buzz

    else if i % 5 == 0 {
        print("\(i) Buzz")
    }
    // if the number is a multiple of 3, print fizz
    else if i % 3 == 0 {
        print("\(i) Fizz")
    }
    // else just print the number
    else{
        print(i)
    }
    // update the counter
    i+=1
}

